This folder contains the UAV Search Cell-DEVS model implemented in CD++

/**************************/
/****FILES ORGANIZATION****/
/**************************/

[DOCUMENTATION]
README.txt
docs\UAVSearchModel.docx
docs\UnmannedAerialVehicleCoveragePathPlanning.pdf
docs\form_UAVSearch.docx

[COLOR FILES]
UAVSearch.col
UAVSearch.pal

[MODEL FILES]
UAVSearchLarge.ma
UAVSearchSmall.ma
UAVSearchInput.val

[TEST SCRIPTS]
SingleUAVTest.bat
RunAllTests.bat
Fig4Test.bat
Fig5Test.bat
FindTargetTest.bat
MultipleUAVsTest.bat
MultiUAVMultiTargetTest.bat

[TEST INPUT FILES]
SingleUAVTest.val
Fig4Test.val
Fig5Test.val
FindTargetTest.val
MultipleUAVsTest.val
MultiUAVMultiTargetTest.val

[EXPERIMENT SCRIPTS]
RunAllExperiments.bat
FiveUAVsExp.bat
UAVRevisitTimeExp.bat
UAVTargetFindExp.bat

[EXPERIMENT INPUT FILES]
FiveUAVsExp.val
UAVRevisitTimeExp.val
UAVTargetFindExp.val

[VIDEOS]
videos\FiveUAVsExp.webm
videos\UAVRevisitTimeExp.webm
videos\UAVTargetFindExp.webm

[OUTPUTS]
Outputs\Fig4Test.drw
Outputs\Fig4Test.log
Outputs\Fig5Test.drw
Outputs\Fig5Test.log
Outputs\FindTargetTest.drw
Outputs\FindTargetTest.log
Outputs\FiveUAVsExp.drw
Outputs\FiveUAVsExp.log
Outputs\MultipleUAVsTest.drw
Outputs\MultipleUAVsTest.log
Outputs\MultiUAVMultiTargetTest.drw
Outputs\MultiUAVMultiTargetTest.log
Outputs\SingleUAVTest.drw
Outputs\SingleUAVTest.log
Outputs\UAVRevisitTimeExp.drw
Outputs\UAVRevisitTimeExp.log
Outputs\UAVTargetFindExp.drw
Outputs\UAVTargetFindExp.log

/*******************/
/****Information****/
/*******************/

0 - UAVSearchModel.docx contains the explanation for this model.  This model has many assumptions please review all assumptions prior to creating your own experiments using this model. 

1 - Notes about the model
	a - Dependencies - Each test and experiment is scripted to run the model, then drawlog and optionally graflog if the comment is removed from the script file.  Please ensure you have the following executables to run the BAT files correctly.
		i - SIMU.exe
		ii - DRAWLOG.exe
		iii - GragLog.exe (optional)
	b - Two dimensions were required for this model.  The 10x10 dimension for testing and the 30x30 dimension for experimentation.  This resulted in two model files UAVSearchSmall.ma for 10x10 and UAVSearchLarge.ma for 30x30.
	c - Both models take an initial value file called UAVSearchInput.val.  The following valid values can be used in the file:
		Searched	0
		Obstacle	1
		Unsearched	6
		Target	7
		UAV	11
	
2 - Color Mapping
	Color mappings for each object are:
	Searched - Green (0 255 0)
	Obstacle - Black (0 0 0)
	Found - Yellow (255 255 0)
	UAV - Purple (255 0 255)
	Unsearched - White (255 255 255)
	Target - Orange (255 128 0)

**SCRIPT NOTES**
a - All test and experiment scripts copy the associated .val file to UAVSearchInput.val first and then run the model.  This allows the model to run for different scenarios.
b - The name of the script is also the name of the input .val file.
c - The name of the script is also the name of the two output files in the output directory.  A .log file and .drw file is produced for each test or experiment.

3 - Tests - All tests can be executed using RunAllTests.bat.  Individual tests can be executed using the following:
	a - SingleUAVTest.bat
	b - Fig4Test.bat
	c - Fig5Test.bat
	d - FindTargetTest.bat
	e - MultipleUAVsTest.bat
	f - MultiUAVMultiTargetTest.bat
	
4 - Experiments - All experiments can be executed using RunAllExperiments.bat.  Individual experiments can be executed using the following:
	a - FiveUAVsExp.bat
	b - UAVRevisitTimeExp.bat
	c - UAVTargetFindExp.bat
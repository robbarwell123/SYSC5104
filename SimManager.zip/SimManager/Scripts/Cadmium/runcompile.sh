cd /common/experiments/$1
make sim
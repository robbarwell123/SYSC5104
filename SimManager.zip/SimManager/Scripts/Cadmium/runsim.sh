cd /common/experiments/$1
./sim
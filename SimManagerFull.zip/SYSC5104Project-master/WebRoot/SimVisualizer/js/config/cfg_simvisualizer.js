// Configuration Variables

// Used to configure REST services
var Addr_GetLogs="http://localhost:8083/GetJSONLog?iId=";
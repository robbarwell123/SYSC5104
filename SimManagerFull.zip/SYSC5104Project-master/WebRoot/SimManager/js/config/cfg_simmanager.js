// Configuration Variables

// Used to configure REST services
var Addr_CreateExperiment="http://localhost:8081/CreateExperiment";
var Addr_DeleteExperiment="http://localhost:8081/DeleteExperiment?iId=";
var Addr_ListExperimentFiles="http://localhost:8081/ListExperimentFiles?iId=";
var Addr_SimLoad="http://localhost:8081/GetSimList";
var Addr_RunCadmium="http://localhost:8082/RunCadmium";
var Addr_DownloadLogs="http://localhost:8083/DownloadLogs?iId=";
var Addr_SimVis="http://localhost/Sim/SimVisualizer/index.php?iId=";

cd /common
make clean
make -f makefiledocker common
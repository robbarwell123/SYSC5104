// Configuration Variables

// Used to configure REST services
var Addr_GetLogs="http://localhost:8093/GetJSONLog?iId=";
// Configuration Variables

// Used to configure REST services
var Addr_CreateExperiment="http://localhost:8091/CreateExperiment";
var Addr_DeleteExperiment="http://localhost:8091/DeleteExperiment?iId=";
var Addr_SimLoad="http://localhost:8091/GetSimList";
var Addr_ListExperimentFiles="http://localhost:8091/ListExperimentFiles?iId=";
var Addr_RunCadmium="http://localhost:8092/RunCadmium";
var Addr_DownloadLogs="http://localhost:8093/DownloadLogs?iId=";
var Addr_SimVis="http://localhost:81/index.php?iId=";
